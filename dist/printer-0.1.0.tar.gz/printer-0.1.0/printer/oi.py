def printador(ars):
    print('Funciona')